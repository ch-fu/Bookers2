class BooksController < ApplicationController

  def index
    @new_book = Book.new
    @user = current_user
    @users = User.all
    @books = Book.all
  end

  def show
    @book = Book.find(params[:id])
    @user = User.find(@book.user.id)
    @users = @book.user
    @books = Book.all
    @new_book = Book.new
  end

  def create
    @new_book = Book.new(book_params)
    @new_book.user_id = current_user.id  # ★投稿したユーザーを設定
    if @new_book.save
      flash[:notice] = 'You have created book successfully.'
      redirect_to book_path(@new_book.id)
    else
      @user = current_user
      @books = Book.all
      render :index
    end
  end

  def edit
    @book = Book.find(params[:id])

    if @book.user != current_user  # 投稿したユーザーがログインユーザーでなければ
     redirect_to books_path  # 投稿一覧（books#index）へリダイレクト
    end
  end

  def update
    @book = Book.find(params[:id])
    if @book.update(book_params)
      flash[:notice] = 'You have updated book successfully.'
      redirect_to book_path(@book.id)
    else
      render :edit
    end
  end

  def destroy
    book = Book.find(params[:id])
    book.destroy
    redirect_to books_path
  end

  private

  def book_params
    params.require(:book).permit(:title, :body)
  end
end
