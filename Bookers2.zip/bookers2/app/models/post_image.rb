class PostImage < ApplicationRecord
end
