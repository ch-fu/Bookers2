# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = 'fb276451248203b714e3b7ccd98862346c427cdde462400ff59aa8662e3762c745f2b2182770926478a5e6735691a7dbd81da8cf1f668a087d2cd5a0474ed9ee'
